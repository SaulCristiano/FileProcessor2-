#define _XOPEN_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>

#define NUM_THREADS 4
#define MAX_LINE_LENGTH 1024
#define MAX_USER_LENGTH 64
#define SHM_NAME "/my_shared_memory"
#define MAX_PATH 1024

sem_t sem;
int moni = 0;

char ruta_consolidado[MAX_PATH];
char ruta_log[MAX_PATH];

// Estructura para almacenar los ID de usuario y su conteo
typedef struct UserNode
{
    char id[MAX_USER_LENGTH];
    int count;
    struct UserNode *next;
} UserNode;

void *threadFunc1(void *arg)
{
    sem_wait(&sem); // Espera hasta que el semáforo esté disponible

    // Acceder a la memoria compartida
    SharedRecord *shared_records = (SharedRecord *)shm_base;

    FILE *log_fp = fopen(ruta_log, "a");
    if (log_fp == NULL)
    {
        printf("No se pudo abrir el archivo de registro.\n");
        sem_post(&sem); // Libera el semáforo antes de salir
        return NULL;
    }

    // Recorrer los registros en la memoria compartida
    for (int i = 0; i < size_fp / sizeof(SharedRecord); i++)
    {
        char user[MAX_USER_LENGTH];
        char time_str[MAX_USER_LENGTH];
        char status[MAX_USER_LENGTH];

        // Extraer los datos del registro actual
        sscanf(shared_records[i].content, "%*[^;];%[^;];%*[^;];%[^;];%*[^;];%*[^;];%[^;]", time_str, user, status);

        // Elimina el carácter de nueva línea de status
        status[strcspn(status, "\n")] = 0;

        // Si el registro está vacío, salir del bucle
        if (strlen(user) == 0)
        {
            break;
        }

        // Si el status indica un error, escribir en el archivo de registro
        if (strcmp(status, "Error") == 0)
        {
            printf("El patrón 1 ha sido detectado en el usuario %s.\n", user);
            fprintf(log_fp, "El patrón 1 ha sido detectado en el usuario %s.\n", user);
            moni++;
        }
    }

    fclose(log_fp);

    sem_post(&sem); // Libera el semáforo
    return NULL;
}


void *threadFunc2(void *arg)
{
    sem_wait(&sem); // Espera hasta que el semáforo esté disponible

    // Acceder a la memoria compartida
    SharedRecord *shared_records = (SharedRecord *)shm_base;

    FILE *log_fp = fopen(ruta_log, "a");
    if (log_fp == NULL)
    {
        printf("No se pudo abrir el archivo de registro.\n");
        sem_post(&sem); // Libera el semáforo antes de salir
        return NULL;
    }

    // Recorrer los registros en la memoria compartida
    for (int i = 0; i < size_fp / sizeof(SharedRecord); i++)
    {
        char user[MAX_USER_LENGTH];
        char time_str[MAX_USER_LENGTH];
        char status[MAX_USER_LENGTH];

        // Extraer los datos del registro actual
        sscanf(shared_records[i].content, "%*[^;];%[^;];%*[^;];%[^;];%*[^;];%*[^;];%[^;]", time_str, user, status);

        // Elimina el carácter de nueva línea de status
        status[strcspn(status, "\n")] = 0;

        // Si el registro está vacío, salir del bucle
        if (strlen(user) == 0)
        {
            break;
        }

        // Si el status indica un error, escribir en el archivo de registro
        if (strcmp(status, "Error") == 0)
        {
            printf("El patrón 2 ha sido detectado en el usuario %s.\n", user);
            fprintf(log_fp, "El patrón 2 ha sido detectado en el usuario %s.\n", user);
            moni++;
        }
    }

    fclose(log_fp);

    sem_post(&sem); // Libera el semáforo
    return NULL;
}


void *threadFunc3(void *arg)
{
    sem_wait(&sem); // Espera hasta que el semáforo esté disponible

    // Acceder a la memoria compartida
    SharedRecord *shared_records = (SharedRecord *)shm_base;

    // Abrir el archivo de reporte para escribir
    FILE *report_fp = fopen(ruta_reporte, "w");
    if (report_fp == NULL)
    {
        printf("No se pudo abrir el archivo de reporte.\n");
        sem_post(&sem); // Libera el semáforo antes de salir
        return NULL;
    }

    // Escribir encabezado en el archivo de reporte
    fprintf(report_fp, "Tiempo;Usuario;Intentos de Ingreso\n");

    // Recorrer los registros en la memoria compartida
    for (int i = 0; i < size_fp / sizeof(SharedRecord); i++)
    {
        char user[MAX_USER_LENGTH];
        char time_str[MAX_TIME_LENGTH];
        char status[MAX_STATUS_LENGTH];

        // Extraer los datos del registro actual
        sscanf(shared_records[i].content, "%*[^;];%[^;];%*[^;];%[^;];%*[^;];%*[^;];%[^;]", time_str, user, status);

        // Si el registro está vacío, salir del bucle
        if (strlen(user) == 0)
        {
            break;
        }

        // Contar los intentos de ingreso exitosos para el usuario actual
        if (strcmp(status, "Success") == 0)
        {
            userAttempts[i]++;
        }
    }

    // Escribir los registros en el archivo de reporte
    for (int i = 0; i < size_fp / sizeof(SharedRecord); i++)
    {
        char user[MAX_USER_LENGTH];

        // Extraer el nombre de usuario del registro actual
        sscanf(shared_records[i].content, "%*[^;];%[^;];%*[^;];%*[^;];%*[^;];%*[^;];%*[^;]", user);

        // Si el registro está vacío, salir del bucle
        if (strlen(user) == 0)
        {
            break;
        }

        // Escribir el registro en el archivo de reporte
        fprintf(report_fp, "%s;%s;%d\n", getTime(), user, userAttempts[i]);
    }

    fclose(report_fp);

    sem_post(&sem); // Libera el semáforo
    return NULL;
}


void *threadFunc4(void *arg)
{
    sem_wait(&sem); // Espera hasta que el semáforo esté disponible

    FILE *file = fopen(ruta_consolidado, "r");
    if (file == NULL)
    {
        printf("No se pudo abrir el archivo consolidado.csv (Func4)\n");
        return NULL;
    }

    char line[MAX_LINE_LENGTH];
    char user[MAX_USER_LENGTH];
    char time_str[MAX_USER_LENGTH];
    char operation[MAX_USER_LENGTH];
    struct tm tm;
    UserNode *head = NULL;
    UserNode *current = NULL; // Añade esta línea

    // Leer el archivo y almacenar los ID de usuario únicos
    while (fgets(line, sizeof(line), file))
    {
        sscanf(line, "%*[^;];%[^;];%*[^;];%[^;];%[^;];%*[^;];%*[^;]", time_str, user, operation);

        // Elimina el carácter de nueva línea de operation
        operation[strcspn(operation, "\n")] = 0;

        // Comprobar si el usuario ya está en la lista
        UserNode *current = head;
        while (current != NULL && strcmp(current->id, user) != 0)
        {
            current = current->next;
        }

        // Si el usuario no está en la lista, añadirlo
        if (current == NULL)
        {
            UserNode *new_node = malloc(sizeof(UserNode));
            strcpy(new_node->id, user);
            new_node->next = head;
            head = new_node;
        }
    }

    // Verificar cada usuario para los diferentes tipos de operación en un mismo día
    current = head;
    while (current != NULL)
    {
        fseek(file, 0, SEEK_SET); // Volver al principio del archivo
        int retirada = 0, bizum = 0, transaccion = 0, compra = 0;
        char current_day[11] = "";

        while (fgets(line, sizeof(line), file))
        {
            sscanf(line, "%*[^;];%[^;];%*[^;];%[^;];%[^;];%*[^;];%*[^;]", time_str, user, operation);

            // Elimina el carácter de nueva línea de operation
            operation[strcspn(operation, "\n")] = 0;

            // Si es el mismo usuario y la operación ocurrió en el mismo día
            if (strcmp(user, current->id) == 0 && strncmp(time_str, current_day, 10) == 0)
            {
                if (strcmp(operation, "RETIRADA") == 0)
                {
                    retirada = 1;
                }
                else if (strcmp(operation, "BIZUM") == 0)
                {
                    bizum = 1;
                }
                else if (strcmp(operation, "TRANSFERENCIA") == 0)
                {
                    transaccion = 1;
                }
                else if (strcmp(operation, "COMPRA") == 0)
                {
                    compra = 1;
                }
            }
            else if (strcmp(user, current->id) == 0)
            {
                // Si es el mismo usuario pero en un día diferente, reinicia los contadores de operación
                strncpy(current_day, time_str, 10);
                retirada = (strcmp(operation, "RETIRADA") == 0) ? 1 : 0;
                bizum = (strcmp(operation, "BIZUM") == 0) ? 1 : 0;
                transaccion = (strcmp(operation, "TRANSFERENCIA") == 0) ? 1 : 0;
                compra = (strcmp(operation, "COMPRA") == 0) ? 1 : 0;
            }

            // Si un usuario ha hecho al menos una operación de cada tipo en un mismo día
            if (retirada && bizum && transaccion && compra)
            {
                // Redirige stdout al archivo log.log
                FILE *log_fp = fopen(ruta_log, "a");
                if (log_fp == NULL)
                {
                    printf("No se pudo abrir el archivo de registro.\n");
                    return 1;
                }

                // Ahora, puedes usar fprintf para escribir en ambos, la pantalla y el archivo.
                printf("El patrón 4 ha sido detectado en el usuario %s en el día %s.\n", current->id, current_day);
                fprintf(log_fp, "El patrón 4 ha sido detectado en el usuario %s en el día %s.\n", current->id, current_day);

                // Cierra el archivo de registro.
                fclose(log_fp);

                moni++;
                break;
            }
        }

        current = current->next;
    }

    // Liberar la memoria de la lista
    while (head != NULL)
    {
        UserNode *next = head->next;
        free(head);
        head = next;
    }

    fclose(file);

    sem_post(&sem); // Libera el semáforo
    return NULL;
}

int main()
{
    char line[MAX_PATH];
    FILE *fp = fopen("fp.conf", "r");
    char lines[MAX_PATH];

    while (fgets(lines, sizeof(lines), fp))
    {
        if (strncmp(lines, "INVENTORY_FILE=", 15) == 0)
        {
            strcpy(ruta_consolidado, lines + 15);
            ruta_consolidado[strcspn(ruta_consolidado, "\n")] = 0; // Eliminar el salto de línea al final
        }
        else if (strncmp(lines, "LOG_FILE=", 9) == 0)
        {
            strcpy(ruta_log, lines + 9);
            ruta_log[strcspn(ruta_log, "\n")] = 0; // Eliminar el salto de línea al final
        }
    }
    fclose(fp);
    pthread_t threads[NUM_THREADS];
    sem_init(&sem, 0, 1); // Inicializa el semáforo

    // Crea los hilos
    pthread_create(&threads[0], NULL, threadFunc1, NULL);
    pthread_create(&threads[1], NULL, threadFunc2, NULL);
    pthread_create(&threads[2], NULL, threadFunc3, NULL);
    pthread_create(&threads[3], NULL, threadFunc4, NULL);

    // Espera a que todos los hilos terminen
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }
    if (moni == 0)
    {
        printf("No se han detectado patrones.");
    }
    else
    {
        printf("Los patrones detectados se han guardado en el archivo %s", ruta_log);
    }
    sem_destroy(&sem); // Destruye el semáforo
    return 0;
}
