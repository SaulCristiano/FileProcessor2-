#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <signal.h>
#include <time.h>

#define MAX_PATH 1024
#define MAX_RESPONSE 10
#define SHM_NAME "/my_shared_memory"
#define MAX_CONTENT_SIZE 2048 // Ajusta según el tamaño esperado del contenido del archivo

sem_t *sems; // Se asigna de forma dinámica
char dir_comun[MAX_PATH];
char ruta_consolidado[MAX_PATH];
int valor_sleep;
char ruta_log[MAX_PATH];
char sucursal_dir_name[MAX_PATH];
int size_fp; // Tamaño de la memoria compartida
char ruta_leido[MAX_PATH]; // Nueva variable para la ruta a la carpeta "leido"

typedef struct {
    char content[MAX_CONTENT_SIZE];
} SharedRecord;

SharedRecord *shared_records = NULL;
int shm_fd;
void *shm_base;
int num_procesos;

// Función para cargar el contenido de consolidado.csv en la memoria compartida
void cargar_consolidado_en_memoria_compartida(const char *ruta_consolidado) {
    FILE *consolidado_file = fopen(ruta_consolidado, "r");
    if (consolidado_file == NULL) {
        perror("Error al abrir el archivo consolidado para cargar");
        return;
    }

    char line[MAX_CONTENT_SIZE];
    int i = 0;
    while (fgets(line, sizeof(line), consolidado_file) && i < size_fp / sizeof(SharedRecord)) {
        line[strcspn(line, "\n")] = '\0'; // Eliminar el salto de línea
        strcpy(shared_records[i].content, line);
        i++;
    }

    fclose(consolidado_file);
}

// Manejador de la señal SIGINT
void manejador_sigint(int signo) {
    printf("Interrupción detectada, volcando memoria compartida a consolidado.csv...\n");

    FILE *consolidado_file = fopen(ruta_consolidado, "w");
    if (consolidado_file == NULL) {
        perror("Error al abrir el archivo consolidado");
        exit(EXIT_FAILURE);
    }

    sem_wait(&sems[0]);
    for (int i = 0; i < size_fp / sizeof(SharedRecord); i++) {
        if (shared_records[i].content[0] != '\0') {
            fprintf(consolidado_file, "%s\n", shared_records[i].content);
        }
    }
    sem_post(&sems[0]);

    fclose(consolidado_file);

    munmap(shm_base, size_fp);
    close(shm_fd);
    shm_unlink(SHM_NAME);

    for (int i = 0; i < num_procesos; i++) {
        sem_destroy(&sems[i]);
    }

    free(sems);

    exit(EXIT_SUCCESS);
}

void *escribir_archivos_y_mover(void *arg)
{
    int num_proceso = *((int *)arg);
    char dir_sucursal[MAX_PATH];
    sprintf(dir_sucursal, "%s/%s%d", dir_comun, sucursal_dir_name, num_proceso);

    while (1)
    {
        DIR *dir = opendir(dir_sucursal);
        if (dir == NULL)
        {
            perror("No se pudo abrir el directorio de la sucursal");
            printf("Sucursal: %d", num_proceso);
            return NULL;
        }

        struct dirent *entry;
        while ((entry = readdir(dir)) != NULL)
        {
            if (entry->d_type == DT_REG) // Solo archivos regulares
            {
                char original_filename[MAX_PATH];
                sprintf(original_filename, "%s/%s", dir_sucursal, entry->d_name);

                // Asegurarse de eliminar el salto de línea del nombre del archivo
                original_filename[strcspn(original_filename, "\n")] = 0;

                // Leer el contenido del archivo
                FILE *file = fopen(original_filename, "r");
                if (file == NULL) {
                    perror("Error al abrir el archivo");
                    continue;
                }

                char content[MAX_CONTENT_SIZE];
                size_t content_size = fread(content, 1, MAX_CONTENT_SIZE, file);
                fclose(file); // Cerrar el archivo aquí


                // Mover el archivo a la carpeta 'leido'
                char new_path[MAX_PATH];
                sprintf(new_path, "./%s/%s",ruta_leido, entry->d_name);
                new_path[strcspn(new_path, "\n")] = 0;

                // Intentar mover el archivo después de asegurarse de que está cerrado
                if (rename(original_filename, new_path) == 0)
                {
                    printf("He movido %s a leido\n", entry->d_name);

                    // Registrar en el archivo de log
                    FILE *log_file = fopen(ruta_log, "a");
                    if (log_file != NULL) {
                        time_t now = time(NULL);
                        struct tm *t = localtime(&now);
                        fprintf(log_file, "Se ha procesado el archivo \"%s\" a las %02d:%02d:%02d a fecha %02d/%02d/%04d.\n",
                                entry->d_name, t->tm_hour, t->tm_min, t->tm_sec, t->tm_mday, t->tm_mon + 1, t->tm_year + 1900);
                        fclose(log_file);
                    } else {
                        perror("Error al abrir el archivo de log");
                    }

                    // Escribir el contenido del archivo en la memoria compartida
                    sem_wait(&sems[num_proceso - 1]);
                    for (int i = 0; i < size_fp / sizeof(SharedRecord); i++) {
                        if (shared_records[i].content[0] == '\0') { // Encontrar un espacio vacío
                            memcpy(shared_records[i].content, content, content_size);
                            shared_records[i].content[content_size] = '\0'; // Asegurarse de que esté terminada en null
                            break;
                        }
                    }
                    sem_post(&sems[num_proceso - 1]);
                }
                else
                {
                    perror("Error al mover el archivo");
                }
            }
        }

        closedir(dir);
        sleep(valor_sleep); // Esperar un valor antes de comprobar de nuevo
    }
}

int main()
{
    FILE *fp = fopen("fp.conf", "r");
    char line[MAX_PATH];

    while (fgets(line, sizeof(line), fp))
    {
        if (strncmp(line, "NUM_PROCESOS=", 13) == 0)
        {
            num_procesos = atoi(line + 13);
        }
        else if (strncmp(line, "PATH_FILE=", 10) == 0)
        {
            strcpy(dir_comun, line + 10);
            dir_comun[strcspn(dir_comun, "\n")] = 0; // Eliminar el salto de línea al final
        }
        else if (strncmp(line, "INVENTORY_FILE=", 15) == 0)
        {
            strcpy(ruta_consolidado, line + 15);
            ruta_consolidado[strcspn(ruta_consolidado, "\n")] = 0; // Eliminar el salto de línea al final
        }
        else if (strncmp(line, "SIMULATE_SLEEP=", 14) == 0)
        {
            valor_sleep = atoi(line + 14);
        }
        else if (strncmp(line, "LOG_FILE=", 9) == 0)
        {
            strcpy(ruta_log, line + 9);
            ruta_log[strcspn(ruta_log, "\n")] = 0; // Eliminar el salto de línea al final
        }
        else if (strncmp(line, "SUCURSAL_DIR_NAME=", 18) == 0)
        {
            strcpy(sucursal_dir_name, line + 18);
            sucursal_dir_name[strcspn(sucursal_dir_name, "\n")] = 0; // Eliminar el salto de línea al final
        }
        else if (strncmp(line, "SIZE_FP=", 8) == 0)
        {
            size_fp = atoi(line + 8) * 1024 * 1024; // Convertir de MB a bytes
        }
        else if (strncmp(line, "LEIDO_DIR=", 10) == 0) { // Nueva condición para la ruta a la carpeta "leido"
            strcpy(ruta_leido, line + 10);
            ruta_leido[strcspn(ruta_leido, "\n")] = 0; // Eliminar el salto de línea al final
        }
    }

    fclose(fp);

    sems = malloc(num_procesos * sizeof(sem_t));
    if (sems == NULL)
    {
        printf("Error: No se pudo asignar memoria para sems\n");
        return 1;
    }

    // Inicializa los semáforos
    for (int i = 0; i < num_procesos; i++)
    {
        sem_init(&sems[i], 0, 2); // Inicializa los semáforos con un contador de 2
    }

    // Crear o abrir la memoria compartida
    shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open");
        return EXIT_FAILURE;
    }

    // Dimensionar la memoria compartida
    if (ftruncate(shm_fd, size_fp) == -1) {
        perror("ftruncate");
        return EXIT_FAILURE;
    }

    // Mapear la memoria compartida
    shm_base = mmap(0, size_fp, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_base == MAP_FAILED) {
        perror("mmap");
        return EXIT_FAILURE;
    }
    shared_records = (SharedRecord *)shm_base;

    // Preguntar al usuario si desea ejecutar Banco
    char respuesta[MAX_RESPONSE];
    printf("¿Desea ejecutar Banco antes de iniciar el procesamiento de archivos? (Si/No): ");
    fgets(respuesta, MAX_RESPONSE, stdin);
    respuesta[strcspn(respuesta, "\n")] = 0; // Eliminar el salto de línea al final

    if (strcasecmp(respuesta, "Si") == 0) // Utilizar strcasecmp para comparación insensible a mayúsculas/minúsculas
    {
        // Ejecutar Banco durante 10 segundos
        printf("Ejecutando Banco...\n");
        fflush(stdout);        // Forzar el vaciado del buffer de salida
        system("./Banco &");   // Ejecutar Banco en segundo plano
        sleep(10);             // Esperar 10 segundos
        system("pkill Banco"); // Terminar el proceso Banco
        printf("Banco ha terminado.\n");
        fflush(stdout); // Forzar el vaciado del buffer de salida
    }

    // Cargar el contenido del archivo consolidado en la memoria compartida
    cargar_consolidado_en_memoria_compartida(ruta_consolidado);

    // Manejar la señal SIGINT
    signal(SIGINT, manejador_sigint);

    printf("Iniciando FileProcessor...\n");
    fflush(stdout); // Forzar el vaciado del buffer de salida

    pthread_t threads[num_procesos];
    int proceso_nums[num_procesos];

    for (int i = 0; i < num_procesos; i++)
    {
        proceso_nums[i] = i + 1;
        pthread_create(&threads[i], NULL, escribir_archivos_y_mover, &proceso_nums[i]);
    }

    // Esperar a que todos los hilos terminen
    for (int i = 0; i < num_procesos; i++)
    {
        pthread_join(threads[i], NULL);
    }

    munmap(shm_base, size_fp);
    close(shm_fd);
    shm_unlink(SHM_NAME);

    for (int i = 0; i < num_procesos; i++)
    {
        sem_destroy(&sems[i]);
    }

    free(sems);

    return 0;
}