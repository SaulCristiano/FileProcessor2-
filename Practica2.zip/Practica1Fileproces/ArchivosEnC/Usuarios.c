#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

#define MAX_LINE_LENGTH 100

void crearGrupo(const char* group_name) {
    char command[256];
    snprintf(command, sizeof(command), "sudo groupadd %s", group_name);
    system(command);
}

void crearUsuario(const char* username, const char* group_name) {
    char command[256];
    snprintf(command, sizeof(command), "sudo useradd -m -g %s %s", group_name, username);
    system(command);
}

void cambiarPropietario(const char* filepath, const char* username, const char* group_name) {
    char command[256];
    snprintf(command, sizeof(command), "sudo chown %s:%s %s", username, group_name, filepath);
    system(command);
}

void configurarPermisos(const char* filepath, const char* permissions) {
    char command[256];
    snprintf(command, sizeof(command), "sudo chmod %s %s", permissions, filepath);
    system(command);
}

void asignarPermisosEspecificos(const char* filepath, const char* username, const char* permissions) {
    char command[256];
    snprintf(command, sizeof(command), "sudo setfacl -m u:%s:%s %s", username, permissions, filepath);
    system(command);
}

int main() {
    char respuesta[3];
    FILE *fp;
    char line[MAX_LINE_LENGTH];
    char *filename = "fp.conf";

    printf("¿Ha ejecutado el programa Banco antes de ejecutar este programa? (si/no): ");
    fgets(respuesta, sizeof(respuesta), stdin);
    respuesta[strcspn(respuesta, "\n")] = '\0';

    if (strcmp(respuesta, "no") == 0) {
        printf("Debe ejecutar el programa Banco antes de ejecutar este programa.\n");
        return 0;
    }

    if (strcmp(respuesta, "si") != 0) {
        printf("Respuesta no válida. Debe responder 'si' o 'no'.\n");
        return 0;
    }

    fp = fopen(filename, "r");
    if (fp == NULL) {
        perror("Error al abrir el archivo de configuración");
        return 1;
    }

    char PATH_FILE[MAX_LINE_LENGTH];
    char INVENTORY_FILE[MAX_LINE_LENGTH];
    char LOG_FILE[MAX_LINE_LENGTH];
    int NUM_PROCESOS;
    int SIMULATE_SLEEP;
    char SUCURSAL_DIR_NAME[MAX_LINE_LENGTH];
    int SIZE_FP;
    char LEIDO_DIR[MAX_LINE_LENGTH];

    while (fgets(line, sizeof(line), fp)) {
        if (sscanf(line, "PATH_FILE=%s", PATH_FILE) == 1) continue;
        if (sscanf(line, "INVENTORY_FILE=%s", INVENTORY_FILE) == 1) continue;
        if (sscanf(line, "LOG_FILE=%s", LOG_FILE) == 1) continue;
        if (sscanf(line, "NUM_PROCESOS=%d", &NUM_PROCESOS) == 1) continue;
        if (sscanf(line, "SIMULATE_SLEEP=%d", &SIMULATE_SLEEP) == 1) continue;
        if (sscanf(line, "SUCURSAL_DIR_NAME=%s", SUCURSAL_DIR_NAME) == 1) continue;
        if (sscanf(line, "SIZE_FP=%d", &SIZE_FP) == 1) continue;
        if (sscanf(line, "LEIDO_DIR=%s", LEIDO_DIR) == 1) continue;
    }

    fclose(fp);

    crearGrupo("ufvauditor");

    for (int i = 1; i <= NUM_PROCESOS; i++) {
        char username[20];
        snprintf(username, sizeof(username), "userSU%03d", i);

        crearUsuario(username, "ufvauditor");

        char dir_path[256];
        snprintf(dir_path, sizeof(dir_path), "%s/%s%d", PATH_FILE, SUCURSAL_DIR_NAME, i);

        if (mkdir(dir_path, 0750) == -1 && errno != EEXIST) {
            perror("Error al crear el directorio");
            continue;
        }

        cambiarPropietario(dir_path, username, "ufvauditor");
        configurarPermisos(dir_path, "750");
    }

    crearGrupo("ufvauditores");

    crearUsuario("userfp", "ufvauditores");
    crearUsuario("usermonitor", "ufvauditores");

    // Permisos para userfp
    configurarPermisos("FileProcessor", "701");
    configurarPermisos("Monitor", "701");
    cambiarPropietario("FileProcessor", "userfp", "ufvauditores");
    cambiarPropietario("Monitor", "userfp", "ufvauditores");
    configurarPermisos("fp.conf", "660");
    cambiarPropietario("fp.conf", "root", "ufvauditores");

    // Permisos para usermonitor
    configurarPermisos("Monitor", "701");
    cambiarPropietario("Monitor", "usermonitor", "ufvauditores");

    // Permisos de los archivos en el directorio actual
    system("sudo find . -type f -exec chmod o-rwx {} +");

    printf("Usuarios y directorios creados con éxito.\n");
    return 0;
}
