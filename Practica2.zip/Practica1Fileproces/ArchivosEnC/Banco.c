#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>

#define CONFIG_FILE "fp.conf"

// Estructura para almacenar los valores del archivo de configuración
struct Config {
    char PATH_FILE[100];
    char INVENTORY_FILE[100];
    char LOG_FILE[100];
    int NUM_PROCESOS;
    int SIMULATE_SLEEP;
    char SUCURSAL_DIR_NAME[100];
    char LEIDO_DIR[100];
};

// Función para leer el archivo de configuración y almacenar los valores en la estructura Config
void read_config(struct Config *config) {
    FILE *file = fopen(CONFIG_FILE, "r");
    if (file == NULL) {
        printf("Error: No se pudo abrir el archivo de configuración %s\n", CONFIG_FILE);
        exit(1);
    }
    char line[100];
    while (fgets(line, sizeof(line), file)) {
        char *key = strtok(line, "=");
        char *value = strtok(NULL, "=");

        if (key && value) {
            // Eliminar el carácter de nueva línea si está presente
            value[strcspn(value, "\n")] = 0;

            if (strcmp(key, "PATH_FILE") == 0) {
                strcpy(config->PATH_FILE, value);
            } else if (strcmp(key, "INVENTORY_FILE") == 0) {
                strcpy(config->INVENTORY_FILE, value);
            } else if (strcmp(key, "LOG_FILE") == 0) {
                strcpy(config->LOG_FILE, value);
            } else if (strcmp(key, "NUM_PROCESOS") == 0) {
                config->NUM_PROCESOS = atoi(value);
            } else if (strcmp(key, "SIMULATE_SLEEP") == 0) {
                config->SIMULATE_SLEEP = atoi(value);
            } else if (strcmp(key, "SUCURSAL_DIR_NAME") == 0) {
                strcpy(config->SUCURSAL_DIR_NAME, value);
            } else if (strcmp(key, "LEIDO_DIR") == 0) {
                strcpy(config->LEIDO_DIR, value);
            }
        }
    }
    fclose(file);
}

// Función para verificar y crear un directorio si no existe
void ensure_directory_exists(const char *path) {
    struct stat st = {0};
    if (stat(path, &st) == -1) {
        if (mkdir(path, 0777) == -1) {
            printf("Error al crear el directorio %s\n", path);
            exit(1);
        }
    }
}

// Función para crear directorios para cada sucursal
void create_directories(const char *base_path, const char *sucursal_dir_name, int num_sucursales) {
    ensure_directory_exists(base_path);  // Asegurar que el directorio base exista
    char path[150];
    for (int i = 1; i <= num_sucursales; i++) {
        sprintf(path, "%s/%s%d", base_path, sucursal_dir_name, i);
        if (mkdir(path, 0777) == -1) {
            if (errno != EEXIST) {
                printf("Error al crear el directorio %s\n", path);
                exit(1);
            }
        }
    }
}

void* ejecutar_sucursal(void* arg) {
    int file_num = 1;
    int sucursal_num = *((int*) arg);
    char filename[150]; // aumentar el tamaño para acomodar la ruta completa
    srand(time(0) + sucursal_num); // para generar números aleatorios diferentes para cada sucursal

    // Leer la configuración del archivo
    struct Config config;
    read_config(&config);

    while (1) {
        // Obtener la fecha actual
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        int day = tm.tm_mday;
        int month = tm.tm_mon + 1; // Los meses en C empiezan desde 0
        int year = tm.tm_year + 1900; // Los años en C empiezan desde 1900
        int hour = tm.tm_hour;
        int min = tm.tm_min;
        // Generar el nombre del archivo utilizando la ruta del archivo de configuración
        sprintf(filename, "%s/%s%d/SU%03d_OPE00%d_%02d%02d%d_%d.data", config.PATH_FILE, config.SUCURSAL_DIR_NAME, sucursal_num, sucursal_num, sucursal_num, day, month, year, file_num);

        // Abrir el archivo para escritura
        FILE *file = fopen(filename, "w");
        if (file == NULL) {
            printf("Error al abrir el archivo %s\n", filename);
            return (void*) 1;
        }

        // Escribir el contenido del archivo
        fprintf(file, "OPE%d;%02d/%02d/%d %02d:%02d;", sucursal_num, day, month, year, hour, min);
        hour = (hour + (rand() % 25)) % 24; // Añadir un número aleatorio de horas a la hora actual
        int user_id = (sucursal_num - 1) * 10 + (rand() % 10) + 1; // Generar un ID de usuario basado en el número de sucursal
        // Generar un número aleatorio entre 1 y 4 para representar las operaciones
        int operacion_num = rand() % 4 + 1;

        // Asignar una cadena de texto correspondiente a la operación
        const char *operacion;
        switch (operacion_num) {
        case 1:
            operacion = "COMPRA";
            break;
        case 2:
            operacion = "RETIRADA";
            break;
        case 3:
            operacion = "TRANSFERENCIA";
            break;
        case 4:
            operacion = "BIZUM";
            break;
        }

        fprintf(file, "%02d/%02d/%d %02d:%02d;USER%d;%s;%d;", day, month, year, hour, min, user_id, operacion, sucursal_num);

        switch (rand() % 3) {
        case 0:
            fprintf(file, "Error");
            break;
        case 1:
            fprintf(file, "Finalizado");
            break;
        case 2:
            fprintf(file, "Correcto");
            break;
        }
        fprintf(file, "\n");

        // Cerrar el archivo
        fclose(file);

        printf("Archivo %s creado.\n", filename);

        // Ahora incrementa el numero de archivo
        file_num++;
        // Esperar el tiempo definido en el archivo de configuración antes de crear el próximo archivo
        sleep(config.SIMULATE_SLEEP);
    }

    return 0;
}

int main() {
    // Leer la configuración del archivo
    struct Config config;
    read_config(&config);

    // Asegurarse de que el directorio base y el directorio 'leido' existan
    ensure_directory_exists(config.PATH_FILE);
    ensure_directory_exists(config.LEIDO_DIR);

    // Crear directorios para cada sucursal
    create_directories(config.PATH_FILE, config.SUCURSAL_DIR_NAME, config.NUM_PROCESOS);

    // Asegurarse de que los archivos de consolidado y log existen
    FILE *file_consolidado = fopen(config.INVENTORY_FILE, "a");
    if (file_consolidado == NULL) {
        printf("Error al crear/abrir el archivo %s\n", config.INVENTORY_FILE);
        return 1;
    }
    fclose(file_consolidado);

    FILE *file_log = fopen(config.LOG_FILE, "a");
    if (file_log == NULL) {
        printf("Error al crear/abrir el archivo %s\n", config.LOG_FILE);
        return 1;
    }
    fclose(file_log);

    pthread_t threads[config.NUM_PROCESOS];
    int sucursal_nums[config.NUM_PROCESOS];

    for(int i = 0; i < config.NUM_PROCESOS; i++) {
        sucursal_nums[i] = i + 1;
        pthread_create(&threads[i], NULL, ejecutar_sucursal, &sucursal_nums[i]);
    }

    for(int i = 0; i < config.NUM_PROCESOS; i++) {
        pthread_join(threads[i], NULL);
    }

    return 0;
}